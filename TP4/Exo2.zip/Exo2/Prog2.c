# include <stdio.h>
# include <stdlib.h>
# include <errno.h>
# include <string.h>
# include <sys/types.h>
# include <sys/msg.h>
# include <unistd.h>
# include <sys/ipc.h>
# include <sys/shm.h>
# include <sys/sem.h>
# include <sys/types.h>
#include <semaphore.h>
//L'objectif est d'utiliser un tableau d'operation afin d'effectuer de manière atomique une décrémentation et une attente

void my_err(char *message) {
    perror(message);
    exit(1);
};

int main(){
  //int Resultat[1];
  struct sembuf sops[2];
  int semaphore_id;
  key_t maCle=ftok("./Fichier",10);//Creation de la clef

  semaphore_id = semget(maCle, 1, IPC_CREAT | 0666); //Obtention d'un identifiant de sémaphore
  if(semaphore_id==-1){
    my_err("Erreur à la création du sémaphore\n");
  }
  printf("Je travail \n");
  //On décremente
  //Test utilisation sembuf

  sops[0].sem_num = 0;        /* Operate on semaphore 0 */
  sops[0].sem_op = 0;        /* Decremente value by one */
  sops[0].sem_flg = 0;

  sops[1].sem_num = 0;        /* Operate on semaphore 0 */
  sops[1].sem_op = -1;         /* Wait for value to equal 0 */
  sops[1].sem_flg = 0;

  if (semop(semaphore_id, sops, 2) == -1) {
     my_err("Erreur d'operation\n");
  }

   printf("Je quitte le rdv\n");
   return 0;
}
